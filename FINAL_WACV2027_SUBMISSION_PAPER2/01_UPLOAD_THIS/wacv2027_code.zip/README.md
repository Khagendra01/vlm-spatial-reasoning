# Paper 2 - What Spatial Fine-Tuning Actually Changes (code + data)

Reproducibility package for the WACV 2027 Datasets-Track submission.

## Contents
- scripts/  - seed-campaign training/eval launchers, the frozen Tier-A/B/C
              analyzers, the independent numerical audit, claim-hierarchy
              freeze, figure/table generation, and the hostile numerical
              reviewer.
- results/seed_campaign/ - frozen analysis, audit (PASS), claim hierarchy,
              literature/novelty audit, hostile review, submission freeze,
              canonical figures and publication tables.
- results/grounding/protocol/ - frozen manifests: VSR test IDs (n=2195),
              visual eligibility (hflip_flip n=245, hflip_invariant n=421),
              semantic eligibility (relcomp n=666), facing eligibility
              (n=103), shuffle mapping, and the run-config snapshot.

## Numbers
Every number in the paper is sourced from results/seed_campaign/
numerical_audit.json, produced by scripts/audit_paper2_numbers_independent.py
(standalone reimplementation from raw prediction artifacts; hard-fail rules;
verdict PASS). Raw prediction CSVs/JSONL are archived in the repository under
results/seed_campaign/cloud_artifacts/ (large; not included in this zip).

## Compute
GPU training/evaluation was performed on rented A6000 machines (see decision
log); this package is the post-compute, frozen artifact layer.
