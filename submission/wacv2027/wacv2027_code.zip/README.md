# Anonymous code archive for CPU reproduction of the analysis in
# "Beyond Spatial Accuracy: Diagnosing Persistent Orientation Failures
# in Vision-Language Models" (WACV 2027 submission)

This archive contains the analysis scripts and the small committed data files
needed to recompute every table, statistic, and figure in the paper on a CPU.
No model weights, media files, or GPU code paths are required for the commands
below.

## Layout

```
scripts/                     analysis + canonical-table + figure scripts
src/datasets/site.py         SITE loader + orientation-keyword rule (reference)
results/                     committed prediction CSVs, metrics JSONs, protocol,
                             probe results, consistency stats, canonical tables
README.md                    this file
requirements.txt             python dependencies
```

## Environment

- Python >= 3.10 (tested on 3.12)
- `pip install -r requirements.txt`

## CPU-reproducible results (no GPU, no checkpoints)

Run everything from the archive root:

| Command | Reproduces |
|---|---|
| `python scripts/build_canonical_tables.py` | `results/tables/vsr_conditions_table.{csv,md}` (10-condition Table 1) and `results/tables/site_validation_table.{csv,md}` (SITE transfer table) |
| `python scripts/compare_site_zeroshot_lora.py` | `results/site/vsr_lora_vs_zeroshot.json` (paired zero-shot vs VSR-LoRA on the 2,591 frozen SITE examples; frozen-ID subsets) |
| `python scripts/site_confound_analysis.py` | `results/site/orientation_confound_analysis.json` + report (logistic confound analysis, SS5/App. E) |
| `python scripts/consistency_verdict_table.py` | `results/consistency_verdict_table.{json,md}` (verdict patterns incl. expected-under-independence values, App. D) |
| `python scripts/make_paper_figures.py` | `paper/fig/*` charts + `paper/fig/audit_output.txt` (headline-number audit) |
| `python scripts/make_publication_figures.py` | `results/figures/fig1..fig5.png` (publication figures) |
| `python scripts/clean_label_orientation.py` | clean-label sensitivity table (App. C) |

Expected outputs: the values printed by each script match the numbers in the
paper; the audit trail in `paper/fig/audit_output.txt` records the full
number-to-artifact mapping (74.0/80.9/62.8/63.5/65.7/66.4; consistency
36.9/66.0/77.7 with 0/103 both-True; SITE 75.1/59.2, transfer 75.1->71.6
p=0.004, secondary n=2,024 48.3/24.0; confound OR 0.84 p=0.29).

## Results that require checkpoints or a GPU (not included)

- Frozen-feature and object-grounded probes (need the base model + per-patch
  embeddings; aggregate results committed in `results/probe/*.json`).
- LoRA training and evaluation (checkpoints not distributed; per-condition
  metrics JSONs and prediction CSVs are committed in `results/`).
- SITE image inference (prediction CSVs are committed).
- Two-stage decomposition: `scripts/two_stage_reasoning.py` reproduces the
  committed aggregate `results/two_stage_results.json` only if per-patch
  embeddings are re-extracted; the committed pipeline scores agreement with
  the control, not ground-truth accuracy (see paper SS4/App. D).

## Notes

- The SITE orientation subset is defined by the frozen protocol IDs
  (`results/site/site_protocol.json -> frozen_ids.secondary`), intersected
  with the evaluated image IDs; no keyword reconstruction is used in the
  analysis scripts.
- All trained conditions are single-checkpoint runs; the paired McNemar tests
  quantify disagreement on the fixed test examples, not training-run
  variability.
